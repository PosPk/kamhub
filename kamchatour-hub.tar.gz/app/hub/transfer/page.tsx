export default function TransferPage(){return(<main style={{minHeight:'100vh',background:'#000',color:'#fff',padding:24}}>
  <a href="/" style={{color:'#E6C149'}}>← На главную</a><h1 style={{fontWeight:900,fontSize:28,marginTop:12}}>Трансфер</h1>
</main>);} 

